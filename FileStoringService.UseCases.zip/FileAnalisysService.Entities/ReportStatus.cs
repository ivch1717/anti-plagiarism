namespace FileAnalisysService.Entities;

public enum ReportStatus
{
    Pending = 0,
    Completed = 1,
    Failed = 2
}