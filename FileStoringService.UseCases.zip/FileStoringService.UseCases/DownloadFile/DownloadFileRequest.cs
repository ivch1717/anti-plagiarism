namespace FileStoringService.UseCases.DownloadFile;

public sealed record DownloadFileRequest(Guid FileId);