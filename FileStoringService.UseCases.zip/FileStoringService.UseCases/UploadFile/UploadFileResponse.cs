namespace FileStoringService.UseCases.UploadFile;

public sealed record UploadFileResponse(
    Guid Id
);